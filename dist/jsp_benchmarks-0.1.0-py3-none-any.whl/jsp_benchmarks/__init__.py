__version__ = '0.1.0'

from .instance_loader import JSPMetaData, JSPInstance, JSPInstanceLoader
